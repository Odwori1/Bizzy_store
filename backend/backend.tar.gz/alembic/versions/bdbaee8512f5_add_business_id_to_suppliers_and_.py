"""add_business_id_to_suppliers_and_purchase_orders

Revision ID: bdbaee8512f5
Revises: 8eba80a2e6ac
Create Date: 2025-09-29 07:19:46.804316

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'bdbaee8512f5'
down_revision = '8eba80a2e6ac'
branch_labels = None
depends_on = None

def upgrade():
    pass

def downgrade():
    pass
