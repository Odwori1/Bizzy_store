"""merge_heads

Revision ID: a7579b9b26ef
Revises: 2fab14b85d84, f5328394d87e
Create Date: 2025-09-07 12:56:26.575433

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a7579b9b26ef'
down_revision = ('2fab14b85d84', 'f5328394d87e')
branch_labels = None
depends_on = None

def upgrade():
    pass

def downgrade():
    pass
