"""merge_product_and_sale_currency_heads

Revision ID: fcd769111042
Revises: 108b7c6c175e, 9aa6020251dd
Create Date: 2025-09-14 10:41:04.332226

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'fcd769111042'
down_revision = ('108b7c6c175e', '9aa6020251dd')
branch_labels = None
depends_on = None

def upgrade():
    pass

def downgrade():
    pass
