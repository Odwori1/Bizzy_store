"""merge_heads

Revision ID: 7b0d7415769d
Revises: 289dc741a653, 61ea0b2e0633
Create Date: 2025-09-08 17:36:45.987094

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7b0d7415769d'
down_revision = ('289dc741a653', '61ea0b2e0633')
branch_labels = None
depends_on = None

def upgrade():
    pass

def downgrade():
    pass
